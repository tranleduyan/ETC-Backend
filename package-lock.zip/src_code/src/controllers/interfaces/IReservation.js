/** Import neccessary modules */
const MakeReservationServices = require("../services/Reservation/MakeReservation");

/** Exports the modules */
module.exports = {
    MakeReservation: MakeReservationServices.MakeReservation
}
